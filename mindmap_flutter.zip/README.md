# MindMap Flutter App

Generated for Codemagic build.
